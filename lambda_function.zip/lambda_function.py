def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': 'Retorno da Funcao Lambda do LocaslStack feito por Anna, Julio, Vitor, Renat e Pazin'
    }